import express, { Router } from "express";
import { loginAction, logOutAction, registerAction,forgotPassword,verifyOTP,resetPassword } from "../Controllers/userAuthControllers.js";
import isAuthenticated from "../Middlewares/auth.middlewares.js";

const userRoute = express.Router();

userRoute.post('/registeruser',registerAction);
userRoute.post('/login', loginAction);
userRoute.get('/logoutuser',logOutAction);
userRoute.post('/forgot-password', forgotPassword);
userRoute.post('/verify-otp', verifyOTP);
userRoute.post('/reset-password', resetPassword);
export default userRoute;

