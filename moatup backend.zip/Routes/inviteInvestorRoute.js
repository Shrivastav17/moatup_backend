import express from 'express';
import multer from 'multer';
import path from 'path';

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'upload/');
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}_${file.originalname}`);
  },
});

const upload = multer({ storage });

// Create Router
const inviteInvestorRoute = express.Router();

// Handle multiple files: inviteFile and databaseFile
inviteInvestorRoute.post('/inviteInvestor', upload.fields([
  { name: 'inviteFile', maxCount: 1 }, // 'inviteFile' is for the invite file
  { name: 'databaseFile', maxCount: 1 }, // 'databaseFile' is for the database file
]), (req, res) => {
  // Handle the data
  console.log(req.files); // The uploaded files will be in req.files
  res.json({ message: 'Files uploaded successfully' });
});

export default inviteInvestorRoute;