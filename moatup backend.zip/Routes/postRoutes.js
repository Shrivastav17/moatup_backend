import express from "express";
import { addPost, likePost, commentPost } from "../Controllers/postControllers.js";
import isAuthenticated from "../Middlewares/auth.middlewares.js";

const createpostRouter = express.Router();

createpostRouter.post("/post", isAuthenticated, addPost); // Create a post
createpostRouter.put("/post/:postId/like", isAuthenticated, likePost); // Like/Dislike a post
createpostRouter.post("/post/:postId/comment", isAuthenticated, commentPost); // Comment on a post

export default createpostRouter;
