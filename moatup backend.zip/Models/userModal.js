import mongoose from "mongoose";
const { Schema } = mongoose;

const userSchema = new Schema({
    username: { type: String, required: true },
    useremail: { type: String, required: true, unique: true },
    userpass: { type: String, required: true },
    otp: { type: String },
    otpExpires: { type: Date },
    avatar: { type: String, default: '' },
    followers: [{ type: Schema.Types.ObjectId, ref: "users" }],
    following: [{ type: Schema.Types.ObjectId, ref: "users" }],
    timestamp: { type: Date, default: Date.now }
});

const userModel = mongoose.model('users', userSchema);

export default userModel;