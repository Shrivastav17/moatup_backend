import mongoose from "mongoose";
const { Schema } = mongoose;

const postSchema = new Schema({
    userId: { type: Schema.Types.ObjectId, ref: "users", required: true },
    content: { type: String, required: false }, // Optional text content
    media: [{ type: String }], // Array of media file URLs
    likes: [{ type: Schema.Types.ObjectId, ref: "users" }], // List of users who liked the post
    comments: [
        {
            userId: { type: Schema.Types.ObjectId, ref: "users" },
            comment: { type: String },
            timestamp: { type: Date, default: Date.now }
        }
    ],
    timestamp: { type: Date, default: Date.now }
});

const postModel = mongoose.model('posts', postSchema);

export default postModel;
