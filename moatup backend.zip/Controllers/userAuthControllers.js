import { encryptdata, comparedata } from '../Middlewares/encrypt.middlewares.js'
import jwt from 'jsonwebtoken';
import userModel from "../Models/userModal.js";
import isAuthenticated from '../Middlewares/auth.middlewares.js';
import nodemailer from 'nodemailer';


const registerAction = async (req, res) => {
    var {
        username,
        useremail,
        userpass,     
    } = req.body

    var userpass = encryptdata(userpass)
    console.log(userpass);


    const dataToInsert = {
        username: username,
        useremail: useremail,
        userpass: userpass,     
    }
    console.log(dataToInsert);

    try {

        // Check ifuseremail already exists
        const existingUser = await userModel.findOne({ useremail: useremail });

        console.log(existingUser);


        if (existingUser) {
            return res.status(409).send({ status: false, msg: "Email Id Exists" });
        }

        const userRegisterInstances = new userModel(dataToInsert)
        var ansAfterInsert = await userRegisterInstances.save();
        res.status(200).send({ status: true, message: "User Registered", data: ansAfterInsert })
    }
    catch (err) {
        res.status(500).send({ status: false, message: "Error", err })
        console.log(err);

    }
}
const loginAction = async (req, res) => { 
    const { useremail, userpass, username } = req.body;

    try {
        // Find the user byuseremail
        const user = await userModel.findOne({ useremail: useremail });

        if (!user) {
            console.log("User not found");
            return res.status(404).send({ msg: "User not found" });
        }

        console.log("Userfound: ", user);

        // Compare the provided password with the stored hashed password using comparedata function
        const isMatch = comparedata(user.userpass, userpass);



        if (!isMatch) {
            // Passwords do not match, return early
            return res.status(401).send({ msg: "Invalid credentials" });
        }

        // If passwords match, create token and set cookie
        //  1 step Create token payload
        const tokenData = {
            userId: user._id
        };
        // Generate token
        const token = await jwt.sign(tokenData, process.env.TOKEN_SECRET, { expiresIn: "1d" })

        // Set cookie and respond
        return res.status(201).cookie("token", token, { expiresIn: "1d", httpOnly: true })
            .json({ message: `Welcome back ${user.username}`, success: true })
    }

    catch (error) {
        console.log(error);
        res.status(500).send({ msg: "Server error", error });
    }
};

const logOutAction = (req, res) => {
    res.cookie("token", "", { expires: new Date(Date.now()) }).json({
        message: "User Logged Out Successfully"
    });

}

 const forgotPassword = async (req, res) => {
    const {useremail } = req.body;
  
    try {
      // Check if the user exists in the database
      const user = await userModel.findOne({useremail });
      if (!user) {
        return res.status(404).json({ message: 'Email not registered.' });
      }
  
      // Generate a 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      user.otp = otp; // Save the OTP to the database
      user.otpExpires = Date.now() + 5 * 60 * 1000; // OTP valid for 5 minutes
      await user.save();
  
      // Send the OTP viauseremail
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'sakshikirtane30@gmail.com', // Replace with youruseremail
          pass: 'aovalgxzdwifawak', // Replace with youruseremail password
        },
      });
  
      const mailOptions = {
        from: 'sakshikirtane30@gmail.com',
        to:useremail,
        subject: 'Your OTP for Password Reset',
        text: `Your OTP is: ${otp}`,
      };
  
      await transporter.sendMail(mailOptions);
      res.status(200).json({ message: 'OTP sent successfully.' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Failed to send OTP.' });
    }
  };

   const verifyOTP = async (req, res) => {
    const { otp } = req.body;
  
    try {
      // Find the user with the provided OTP
      const user = await userModel.findOne({ otp });
      if (!user) {
        return res.status(400).json({ message: 'Invalid OTP.' });
      }
  
      // Check if the OTP has expired
      if (Date.now() > user.otpExpires) {
        return res.status(400).json({ message: 'OTP has expired.' });
      }
  
      // Clear the OTP and expiration time after successful verification
      user.otp = null;
      user.otpExpires = null;
      await user.save();
  
      res.status(200).json({ message: 'OTP verified successfully.' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Failed to verify OTP.' });
    }
  };

   const resetPassword = async (req, res) => {
    const { otp, password } = req.body;
  
    try {
      // Find user by OTP
      const user = await userModel.findOne({ otp });
      if (!user) {
        return res.status(400).json({ message: 'User not found or OTP expired.' });
      }
  
      // Update the password (hash it before saving in production)
      user.password = password; // Use bcrypt for hashing in a real app
      user.otp = null; // Clear OTP after password reset
      await user.save();
  
      res.status(200).json({ message: 'Password updated successfully.' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Failed to reset password.' });
    }
  };

export {
    registerAction,
    loginAction,
    logOutAction,
    forgotPassword,
    verifyOTP,
    resetPassword
};