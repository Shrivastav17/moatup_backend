import multer from 'multer';
import path from 'path';
import postModel from "../Models/postModal.js";

// Setup Multer for file uploads (media)
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './assets/profiles');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'video/mp4', 'application/pdf'];
        if (allowedTypes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Unsupported file type'), false);
        }
    }
}).array('media');


// Add a Post (including media upload)
export const addPost = (req, res) => {
    upload(req, res, async (err) => {
        if (err) {
            return res.status(500).json({ message: 'Error uploading files', error: err });
        }
        const { content } = req.body;
        const media = req.files ? req.files.map(file => file.path) : [];

        const userId = req.userId;

        try {
            const newPost = new postModel({ userId, content, media });
            const savedPost = await newPost.save();

            res.status(201).json({ message: "Post created successfully", post: savedPost });
        } catch (error) {
            res.status(500).json({ message: "Error creating post", error });
        }
    });
};


// Like or Dislike a Post
export const likePost = async (req, res) => {
    const { postId } = req.params;
    const userId = req.userId;

    try {
        const post = await postModel.findById(postId);

        if (!post) {
            return res.status(404).json({ message: "Post not found" });
        }

        if (post.likes.includes(userId)) {
            // Unlike the post
            post.likes = post.likes.filter((id) => id.toString() !== userId.toString());
        } else {
            // Like the post
            post.likes.push(userId);
        }

        await post.save();
        res.status(200).json({ message: "Post updated successfully", likes: post.likes.length });
    } catch (error) {
        res.status(500).json({ message: "Error liking post", error });
    }
};

// Comment on a Post
export const commentPost = async (req, res) => {
    const { postId } = req.params;
    const { comment } = req.body;
    const userId = req.userId;

    try {
        const post = await postModel.findById(postId);

        if (!post) {
            return res.status(404).json({ message: "Post not found" });
        }

        post.comments.push({ userId, comment });
        await post.save();

        res.status(201).json({ message: "Comment added successfully", comments: post.comments });
    } catch (error) {
        res.status(500).json({ message: "Error adding comment", error });
    }
};

