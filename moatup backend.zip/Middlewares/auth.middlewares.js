import jwt from "jsonwebtoken";

const isAuthenticated = async (req, res, next) => {

    try {   
        const { token } = req.cookies;
        // Log the token for debugging
        console.log("Token received:", token);

        // Check if the token is present
        if (!token) {
            return res.status(401).json({
                message: "User not authenticated. Token is missing.",
                success: false
            });
        }
        const decode = await jwt.verify(token, process.env.TOKEN_SECRET);
        console.log(decode);
        // req.user = decode.id;
        req.userId = decode.userId; 
        next();

    }
    catch (error) {
        console.log(error);
        return res.status(401).json({
            message: "Authentication failed",
            success: false
        });
    }
};
export default isAuthenticated